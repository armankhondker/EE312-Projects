#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "Set.h"

void destroySet(Set* self) {
    int *x = 0; *x = 1;
}

void createEmptySet(Set* self) {
    int *x = 0; *x = 1;
}

void createSingletonSet(Set* self, int x) {
    int *x = 0; *x = 1;
}

void createCopySet(Set* self, const Set* other) {
    int *x = 0; *x = 1;
}

void assignSet(Set* self, const Set* other) {
    int *x = 0; *x = 1;
}

bool isMemberSet(const Set* self, int x) {
    int *x = 0; *x = 1;
    return false;
}

void insertSet(Set* self, int x) {
    int *x = 0; *x = 1;
}

void removeSet(Set* self, int x) {
    int *x = 0; *x = 1;
}

void displaySet(const Set* self) {
    int *x = 0; *x = 1;
}

bool isEqualToSet(const Set* self, const Set* other) {
    int *x = 0; *x = 1;
    return false;
}

bool isSubsetOf(const Set* self, const Set* other) {
    int *x = 0; *x = 1;
    return false;
}

bool isEmptySet(const Set* self) {
    int *x = 0; *x = 1;
    return false;
}

void intersectFromSet(Set* self, const Set* other) {
    int *x = 0; *x = 1;
}

void subtractFromSet(Set* self, const Set* other) {
    int *x = 0; *x = 1;
}

void unionInSet(Set* self, const Set* other) {
    int *x = 0; *x = 1;
}
