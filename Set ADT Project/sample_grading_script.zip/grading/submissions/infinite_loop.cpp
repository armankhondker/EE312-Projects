#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "Set.h"

void destroySet(Set* self) {
    while(1);
}

void createEmptySet(Set* self) {
    while(1);
}

void createSingletonSet(Set* self, int x) {
    while(1);
}

void createCopySet(Set* self, const Set* other) {
    while(1);
}

void assignSet(Set* self, const Set* other) {
    while(1);
}

bool isMemberSet(const Set* self, int x) {
    while(1);
    return false;
}

void insertSet(Set* self, int x) {
    while(1);
}

void removeSet(Set* self, int x) {
    while(1);
}

void displaySet(const Set* self) {
    while(1);
}

bool isEqualToSet(const Set* self, const Set* other) {
    while(1);
    return false;
}

bool isSubsetOf(const Set* self, const Set* other) {
    while(1);
    return false;
}

bool isEmptySet(const Set* self) {
    while(1);
    return false;
}

void intersectFromSet(Set* self, const Set* other) {
    while(1);
}

void subtractFromSet(Set* self, const Set* other) {
    while(1);
}

void unionInSet(Set* self, const Set* other) {
    while(1);
}
